dbl Permission
dblink Permission pdfdbl.elb
