dbl TextDemo
dblink TextDemo pdfdbl.elb
