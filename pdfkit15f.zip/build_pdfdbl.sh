dblproto pdfdbl.dbl
dbl  pdfdbl
dblink -l pdfdbl pdfdbl
